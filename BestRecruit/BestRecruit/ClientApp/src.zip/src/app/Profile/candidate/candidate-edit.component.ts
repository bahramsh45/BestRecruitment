import { Component } from '@angular/core'

@Component({
  selector: 'candidate-edit',
  templateUrl: './candidate-edit.component.html'
})

export class CandidateComponent {

}
