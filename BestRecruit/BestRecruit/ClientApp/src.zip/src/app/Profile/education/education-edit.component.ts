import { Component } from '@angular/core';

@Component({
  selector: 'education',
  templateUrl: './education-edit.component.html'
})
export class EducationComponent {
  

  
}
