import { Component } from '@angular/core';

@Component({
  selector: 'experience-edit',
  templateUrl: './experience-edit.component.html'
})
export class ExperienceComponent {
  

  
}
